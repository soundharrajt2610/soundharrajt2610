import java.util.Scanner;
class Main
{
    public static void main(String args[])
    {
        //fill the code;
      Scanner input = new Scanner(System.in);
      int n = input.nextInt();
      int sum =0;
      int a[] = new int[n];
      int b[] = new int[n];
      for(int i=0;i<n;i++)
      {
        a[i] = input.nextInt();
      }
      for(int j=0;j<n;j++)
      {
        b[j] = input.nextInt();
      }
      for(int i=0;i<n;i++)
      {
        sum = a[i]+b[i];
        System.out.println(sum);
      }
    }
}
